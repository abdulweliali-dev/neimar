import * as React from 'react';
import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

export const buttonVariants = cva('inline-flex items-center justify-center gap-3 whitespace-nowrap rounded-sm text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50', {
  variants: {
    variant: {
      default: 'bg-primary text-primary-foreground hover:bg-primary/90',
      hero: 'bg-accent text-accent-foreground hover:bg-accent/90',
      outline: 'border border-border bg-transparent text-foreground hover:bg-muted',
      ghost: 'bg-transparent text-foreground hover:bg-muted',
    },
    size: { default: 'h-12 px-6', sm: 'h-10 px-4', icon: 'h-10 w-10' },
  },
  defaultVariants: { variant: 'default', size: 'default' },
});
export type ButtonProps = React.ComponentProps<'button'> & VariantProps<typeof buttonVariants> & { asChild?: boolean };
export function Button({ className, variant, size, asChild = false, ...props }: ButtonProps) {
  const Comp = asChild ? Slot : 'button';
  return <Comp className={cn(buttonVariants({ variant, size, className }))} {...props} />;
}