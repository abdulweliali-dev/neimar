import { Link } from '@tanstack/react-router';
import { ArrowUpRight, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { profile } from '@/lib/site-content';

export function Brand() {
  return <Link to="/" className="brand" aria-label="Neimar Consultancy Inc. home"><span className="brand-mark" aria-hidden="true">N<span /></span><span className="brand-name">NEIMAR<span>CONSULTANCY INC.</span></span></Link>;
}
const nav = [{ to: '/', label: 'Home' }, { to: '/about', label: 'About' }, { to: '/services', label: 'Services' }, { to: '/approach', label: 'Our Approach' }] as const;
export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return <header className="site-header"><div className="container header-inner"><Brand /><nav className="desktop-nav" aria-label="Main navigation">{nav.map(item => <Link key={item.to} to={item.to} activeOptions={{ exact: true }} activeProps={{ className: 'nav-active' }}>{item.label}</Link>)}</nav><Button asChild size="sm" className="header-cta"><Link to="/contact">Let’s Talk <ArrowUpRight size={16} /></Link></Button><Button variant="ghost" size="icon" className="mobile-menu-button" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</Button></div>{open && <nav className="mobile-nav" aria-label="Mobile navigation">{[...nav, { to: '/contact', label: 'Let’s Talk' } as const].map(item => <Link key={item.to} to={item.to} onClick={() => setOpen(false)}>{item.label}<ArrowUpRight size={16} /></Link>)}</nav>}</header>;
}
export function ContactBand() {
  return <section className="contact-band"><div className="container contact-band-inner"><div><p className="eyebrow">YOUR NEXT CHAPTER</p><h2>Move forward with clarity.</h2><p>Let’s turn your technology ambition into an actionable path forward.</p></div><Button variant="hero" asChild><Link to="/contact">Start a Conversation <ArrowUpRight size={18} /></Link></Button></div></section>;
}
export function SiteFooter() {
  return <footer className="site-footer"><div className="container footer-top"><div><Brand /><p>From enterprise complexity<br />to strategic advantage.</p></div><div><span className="footer-label">EXPLORE</span><Link to="/about">About Neimar</Link><Link to="/services">Our Services</Link><Link to="/approach">Our Approach</Link></div><div><span className="footer-label">LET’S CONNECT</span><a href={`mailto:${profile.email}?subject=${encodeURIComponent('Consultation inquiry — Neimar Consultancy Inc.')}`}>Discuss your initiative <ArrowUpRight size={15} /></a><p>{profile.email}<br />Senior-level advice. Independent perspective.</p></div></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} Neimar Consultancy Inc. All rights reserved.</span><span>Strategy. Intelligence. Execution.</span></div></footer>;
}