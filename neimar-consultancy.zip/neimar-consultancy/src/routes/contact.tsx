import { createFileRoute } from '@tanstack/react-router';
import { useState, type FormEvent } from 'react';
import { Mail, CheckCircle2 } from 'lucide-react';
import { pageHead, services, profile } from '@/lib/site-content';
import { Button } from '@/components/ui/button';
export const Route = createFileRoute('/contact')({ head: () => pageHead('Let’s Talk', 'Email Neimar Consultancy Inc. at weli.ali@neimarco.com about AI strategy, data governance, cloud adoption, program leadership, executive advisory, or change enablement.'), component: Contact });
function Contact() {
  const [opened, setOpened] = useState(false);
  function sendInquiry(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get('name') || '');
    const organization = String(data.get('organization') || '');
    const subject = encodeURIComponent(`Consultation inquiry — ${organization || name || 'Neimar Consultancy Inc.'}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${data.get('email')}\nOrganization: ${organization || 'Not provided'}\nArea of interest: ${data.get('service')}\n\nInitiative details:\n${data.get('message')}`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setOpened(true);
  }
  const mailto = `mailto:${profile.email}?subject=${encodeURIComponent('Consultation inquiry — Neimar Consultancy Inc.')}`;
  return <><section className="page-intro"><div className="container"><p className="eyebrow">LET’S TALK</p><h1>Your ambition.<br />Our next conversation.</h1><p>Whether you’re shaping a technology roadmap or navigating a mission-critical program, start with a clear picture of what you want to achieve.</p></div></section><section className="section"><div className="container contact-layout"><div><p className="eyebrow">START WITH WHAT MATTERS</p><h2>What’s next for your organization?</h2><p>Tell us about your priorities, your challenges, and the outcomes you’re working toward.</p><div className="contact-note"><strong>Email your inquiry</strong><p>Send your inquiry directly to <a className="contact-email" href={mailto}>{profile.email}</a> — or complete the form and your email app will open with everything ready to send.</p></div></div><form onSubmit={sendInquiry} className="inquiry-form"><div className="form-field"><label htmlFor="name">Full name *</label><input id="name" name="name" autoComplete="name" placeholder="Your name" required /></div><div className="form-field"><label htmlFor="email">Business email *</label><input id="email" name="email" type="email" autoComplete="email" placeholder="you@organization.com" required /></div><div className="form-field full-width"><label htmlFor="organization">Organization</label><input id="organization" name="organization" autoComplete="organization" placeholder="Organization name" /></div><div className="form-field full-width"><label htmlFor="service">Area of interest</label><select id="service" name="service"><option>General strategic advisory</option>{services.map(s => <option key={s.number}>{s.title}</option>)}</select></div><div className="form-field full-width"><label htmlFor="message">Tell us about your initiative *</label><textarea id="message" name="message" placeholder="Your priorities, challenges, and intended outcomes…" required /></div><p className="form-note full-width">Submitting the form opens your own email application with your inquiry ready to send to {profile.email}. Nothing is stored on this website.</p><div className="full-width"><Button type="submit">Send Inquiry <Mail size={17} /></Button></div>{opened && <p role="status" className="form-success full-width"><CheckCircle2 size={19} />Your email app is opening with your inquiry ready to send to {profile.email}.</p>}</form></div></section></>;
}
